//list all of the tweets in the database
db.tweets.find();

//NOTE: If you want to see beyond the first 20, you can get more documents by issuing the `it` command in the console.
